const express = require("express");

const Order =
require("../models/Order");

const verifyToken =
require("../middleware/authMiddleware");

const router = express.Router();
router.post(
    "/",
    verifyToken,
    async (req, res) => {

        const order =
        await Order.create({

            userId:
            req.user.id,

            products:
            req.body.products,

            totalAmount:
            req.body.totalAmount

        });

        res.status(201).json(
            order
        );

});
router.get(
    "/",
    verifyToken,
    async (req, res) => {

        const orders =
        await Order.find({
            userId: req.user.id
        });

        res.json(orders);

});
module.exports = router;