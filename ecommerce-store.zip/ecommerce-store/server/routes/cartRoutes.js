const express = require("express");

const Cart =
require("../models/Cart");

const verifyToken =
require("../middleware/authMiddleware");

const router = express.Router();
router.post(
    "/",
    verifyToken,
    async (req, res) => {

        const cartItem =
        await Cart.create({
            userId: req.user.id,
            productId:
            req.body.productId,
            quantity:
            req.body.quantity
        });

        res.status(201).json(
            cartItem
        );

});
router.get(
    "/",
    verifyToken,
    async (req, res) => {

        const items =
        await Cart.find({
            userId: req.user.id
        }).populate("productId");

        res.json(items);

});
router.delete(
    "/:id",
    verifyToken,
    async (req, res) => {

        await Cart.findByIdAndDelete(
            req.params.id
        );

        res.json({
            message:
            "Item Removed"
        });

});
module.exports = router;