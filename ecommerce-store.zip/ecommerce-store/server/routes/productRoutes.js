const express = require("express");

const Product =
require("../models/Product");

const verifyToken =
require("../middleware/authMiddleware");

const router = express.Router();
router.get("/", async (req, res) => {

    const products =
    await Product.find();

    res.json(products);

});
router.get("/:id", async (req, res) => {

    const product =
    await Product.findById(
        req.params.id
    );

    res.json(product);

});
router.post(
    "/",
    verifyToken,
    async (req, res) => {

        const product =
        await Product.create(
            req.body
        );

        res.status(201).json(
            product
        );

});
router.put(
    "/:id",
    verifyToken,
    async (req, res) => {

        const product =
        await Product.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        res.json(product);

});
router.delete(
    "/:id",
    verifyToken,
    async (req, res) => {

        await Product.findByIdAndDelete(
            req.params.id
        );

        res.json({
            message:
            "Product Deleted"
        });

});
module.exports = router;
