require("dotenv").config();

const express =
require("express");

const mongoose =
require("mongoose");

const cors =
require("cors");

const authRoutes =
require("./routes/authRoutes");

const productRoutes =
require("./routes/productRoutes");

const cartRoutes =
require("./routes/cartRoutes");

const orderRoutes =
require("./routes/orderRoutes");

const app = express();

app.use(cors());

app.use(express.json());

mongoose.connect(
    process.env.MONGO_URI
)
.then(() =>
console.log(
"MongoDB Connected"
));

app.use(
"/api/auth",
authRoutes
);

app.use(
"/api/products",
productRoutes
);

app.use(
"/api/cart",
cartRoutes
);

app.use(
"/api/orders",
orderRoutes
);

app.listen(
5000,
() => {
    console.log(
    "E-Commerce Server Running"
    );
});