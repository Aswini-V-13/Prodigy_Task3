function ProductCard({
  product,
  addToCart
}) {

  const addToWishlist = () => {

    const wishlist =
    JSON.parse(
      localStorage.getItem("wishlist")
    ) || [];

    const exists =
    wishlist.find(
      item => item._id === product._id
    );

    if (!exists) {

      wishlist.push(product);

      localStorage.setItem(
        "wishlist",
        JSON.stringify(wishlist)
      );

      alert(
        "❤️ Added To Wishlist"
      );

    } else {

      alert(
        "Already In Wishlist"
      );

    }

  };

  return (

    <div
      className="card shadow h-100 border-0 product-card"
    >

      <img
        src={product.image}
        className="card-img-top"
        alt={product.name}
        style={{
          height: "250px",
          objectFit: "cover"
        }}
      />

      <div className="card-body">

        <span
          className="badge bg-secondary mb-2"
        >
          {product.category}
        </span>

        <h5 className="fw-bold">
          {product.name}
        </h5>

        <p
          className="text-muted"
          style={{
            minHeight: "50px"
          }}
        >
          {product.description}
        </p>

        <h4 className="text-success">
          ₹ {product.price}
        </h4>

        <p>
          ⭐⭐⭐⭐⭐
        </p>

        <p>

          <strong>
            Stock:
          </strong>

          {" "}
          {product.stock}

        </p>

        <div
          className="d-flex gap-2"
        >

          <button
            className="btn btn-outline-danger flex-fill"
            onClick={addToWishlist}
          >
            ❤️ Wishlist
          </button>

          <button
            className="btn btn-primary flex-fill"
            onClick={() =>
              addToCart(product._id)
            }
          >
            🛒 Add To Cart
          </button>

        </div>

      </div>

    </div>

  );
}

export default ProductCard;