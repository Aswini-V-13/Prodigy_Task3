function ProductCard({
  product,
  addToCart
}) {

  return (

    <div className="card">

      <img
        src={product.image}
        className="card-img-top"
        alt={product.name}
      />

      <div className="card-body">

        <h5>
          {product.name}
        </h5>

        <p>
          ₹ {product.price}
        </p>

        <button
          className="btn btn-primary"
          onClick={() =>
          addToCart(product._id)}
        >
          Add To Cart
        </button>

      </div>

    </div>
  );
}

export default ProductCard;