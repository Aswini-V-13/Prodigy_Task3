import { Link } from "react-router-dom";

function Navbar() {

  return (

    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow">

      <div className="container">

        <Link
          className="navbar-brand fs-2"
          to="/"
        >
          🛍️ ShopEase
        </Link>

        <div
          className="d-flex align-items-center gap-3"
        >

          <Link
            className="btn btn-danger"
            to="/wishlist"
          >
            ❤️ Wishlist
          </Link>

          <Link
            className="btn btn-light"
            to="/cart"
          >
            🛒 Cart
          </Link>

          <Link
            className="btn btn-light"
            to="/orders"
          >
            📦 Orders
          </Link>

          <Link
            className="btn btn-warning"
            to="/login"
          >
            👤 Login
          </Link>

        </div>

      </div>

    </nav>

  );

}

export default Navbar;