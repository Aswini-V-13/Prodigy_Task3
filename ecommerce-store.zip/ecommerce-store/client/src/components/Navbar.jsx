import { Link } from "react-router-dom";

function Navbar() {

  return (

    <nav className="navbar navbar-dark bg-dark">

      <div className="container">

        <Link
          className="navbar-brand"
          to="/"
        >
          Local Store
        </Link>

        <div>

          <Link
            className="btn btn-light me-2"
            to="/cart"
          >
            Cart
          </Link>

          <Link
            className="btn btn-light me-2"
            to="/orders"
          >
            Orders
          </Link>

          <Link
            className="btn btn-warning"
            to="/login"
          >
            Login
          </Link>

        </div>

      </div>

    </nav>
  );
}

export default Navbar;