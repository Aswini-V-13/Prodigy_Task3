import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";

function Wishlist() {

  const [wishlist, setWishlist] =
  useState([]);

  useEffect(() => {

    const items =
    JSON.parse(
      localStorage.getItem("wishlist")
    ) || [];

    setWishlist(items);

  }, []);

  const removeFromWishlist = (id) => {

    const updated =
    wishlist.filter(
      item => item._id !== id
    );

    localStorage.setItem(
      "wishlist",
      JSON.stringify(updated)
    );

    setWishlist(updated);

  };

  return (

    <>
      <Navbar />

      <div className="container mt-4">

        <h2 className="mb-4">
          ❤️ My Wishlist
        </h2>

        <div className="row">

          {wishlist.length > 0 ? (

            wishlist.map((item) => (

              <div
                key={item._id}
                className="col-md-4 mb-4"
              >

                <div className="card shadow">

                  <img
                    src={item.image}
                    className="card-img-top"
                    alt={item.name}
                    style={{
                      height: "220px",
                      objectFit: "cover"
                    }}
                  />

                  <div className="card-body">

                    <h5>{item.name}</h5>

                    <p>
                      ₹ {item.price}
                    </p>

                    <button
                      className="btn btn-danger"
                      onClick={() =>
                        removeFromWishlist(item._id)
                      }
                    >
                      Remove
                    </button>

                  </div>

                </div>

              </div>

            ))

          ) : (

            <h4>
              No Wishlist Items ❤️
            </h4>

          )}

        </div>

      </div>

    </>
  );
}

export default Wishlist;