import axios from "axios";
import { useEffect, useState } from "react";

function Cart() {

  const [items, setItems] =
  useState([]);

  const token =
  localStorage.getItem("token");

  const fetchCart =
  async () => {

    try {

      const res =
      await axios.get(

        "http://localhost:5000/api/cart",

        {
          headers: {
            Authorization:
            `Bearer ${token}`
          }
        }

      );

      setItems(res.data);

    } catch (error) {

      console.log(error);

    }

  };

  useEffect(() => {

    fetchCart();

  }, []);

  const removeItem =
  async (id) => {

    try {

      await axios.delete(

        `http://localhost:5000/api/cart/${id}`,

        {
          headers: {
            Authorization:
            `Bearer ${token}`
          }
        }

      );

      fetchCart();

    } catch (error) {

      console.log(error);

    }

  };

  const placeOrder =
  async () => {

    try {

      const products =
      items.map((item) => ({

        productId:
        item.productId._id,

        quantity:
        item.quantity

      }));

      const totalAmount =
      items.reduce(

        (sum, item) =>

        sum +
        item.productId.price *
        item.quantity,

        0

      );

      await axios.post(

        "http://localhost:5000/api/orders",

        {
          products,
          totalAmount
        },

        {
          headers: {
            Authorization:
            `Bearer ${token}`
          }
        }

      );

      alert(
        "Order Placed Successfully"
      );

    } catch (error) {

      console.log(error);

    }

  };

  const total =
  items.reduce(

    (sum, item) =>

    sum +
    item.productId.price *
    item.quantity,

    0

  );

  return (

    <div className="container mt-5">

      <h2>My Cart</h2>

      {
        items.length === 0
        ?

        <h4>
          Cart is Empty
        </h4>

        :

        <>
          {
            items.map((item) => (

              <div
                key={item._id}
                className="card p-3 mb-3"
              >

                <h5>
                  {
                    item.productId.name
                  }
                </h5>

                <p>
                  Price:
                  ₹
                  {
                    item.productId.price
                  }
                </p>

                <p>
                  Quantity:
                  {
                    item.quantity
                  }
                </p>

                <button
                  className="btn btn-danger"
                  onClick={() =>
                  removeItem(
                    item._id
                  )}
                >
                  Remove
                </button>

              </div>

            ))
          }

          <h4>
            Total:
            ₹{total}
          </h4>

          <button
            className="btn btn-success"
            onClick={placeOrder}
          >
            Place Order
          </button>

        </>
      }

    </div>
  );
}

export default Cart;