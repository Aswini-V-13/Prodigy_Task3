import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";

function Orders() {

  const [orders, setOrders] =
  useState([]);

  useEffect(() => {

    fetchOrders();

  }, []);

  const fetchOrders =
  async () => {

    try {

      const token =
      localStorage.getItem("token");

      const res =
      await axios.get(

        "http://localhost:5000/api/orders",

        {
          headers: {
            Authorization:
            `Bearer ${token}`
          }
        }

      );

      setOrders(res.data);

    } catch (error) {

      console.log(error);

    }

  };

  return (

    <>
      <Navbar />

      <div className="container mt-4">

        <h2 className="mb-4 text-center">
          📦 My Orders
        </h2>

        {orders.length === 0 ? (

          <div className="alert alert-info text-center">
            No Orders Found
          </div>

        ) : (

          orders.map((order) => (

            <div
              key={order._id}
              className="card shadow-lg border-0 mb-4"
            >

              <div className="card-header bg-success text-white d-flex justify-content-between">

                <h5>
                  Order ID:
                  {" "}
                  {order._id.slice(-6)}
                </h5>

                <span className="badge bg-warning text-dark">
                  Processing
                </span>

              </div>

              <div className="card-body">

                <h6 className="mb-3">
                  🛍️ Ordered Products
                </h6>

                {order.products.map((item, index) => (

                  <div
                    key={index}
                    className="d-flex justify-content-between border-bottom py-2"
                  >

                    <span>
                      Product ID:
                      {" "}
                      {item.productId}
                    </span>

                    <span>
                      Qty:
                      {" "}
                      {item.quantity}
                    </span>

                  </div>

                ))}

                <div className="mt-3">

                  <h5 className="text-success">

                    Total Amount:
                    ₹ {order.totalAmount}

                  </h5>

                </div>

              </div>

            </div>

          ))

        )}

      </div>

    </>

  );

}

export default Orders;