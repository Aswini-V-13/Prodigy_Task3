import axios from "axios";
import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";
import ProductCard from "../components/ProductCard";

function Home() {

  const [products, setProducts] =
  useState([]);

  const [search, setSearch] =
  useState("");

  useEffect(() => {

    const fetchProducts =
    async () => {

      try {

        const res =
        await axios.get(
          "http://localhost:5000/api/products"
        );

        setProducts(res.data);

      } catch (error) {

        console.log(error);

      }

    };

    fetchProducts();

  }, []);

  const addToCart = async (id) => {

    try {

      const token =
      localStorage.getItem("token");

      await axios.post(

        "http://localhost:5000/api/cart",

        {
          productId: id,
          quantity: 1
        },

        {
          headers: {
            Authorization:
            `Bearer ${token}`
          }
        }

      );

      alert(
        "✅ Product Added To Cart"
      );

    } catch (error) {

      console.log(error);

      alert(
        "❌ Failed To Add Product"
      );

    }

  };

  const filteredProducts =
  products.filter((product) =>

    product.name
    .toLowerCase()
    .includes(
      search.toLowerCase()
    )

  );

  return (

    <>

      <Navbar />

      <div className="container mt-4">

        {/* Hero Section */}

        <div
          className="bg-dark text-white text-center p-5 rounded shadow mb-4"
        >

          <h1>
            🛍️ ShopEase
          </h1>

          <p className="lead">

            Discover Amazing Products
            at Great Prices

          </p>

        </div>

        {/* Search Bar */}

        <input

          type="text"

          className="form-control mb-4"

          placeholder="🔍 Search Products..."

          value={search}

          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }

        />

        <h2 className="mb-4">
          Products
        </h2>

        <div className="row">

          {filteredProducts.length > 0 ? (

            filteredProducts.map((product) => (

              <div
                key={product._id}
                className="col-md-4 mb-4"
              >

                <ProductCard

                  product={product}

                  addToCart={addToCart}

                />

              </div>

            ))

          ) : (

            <h4 className="text-center">

              No Products Found

            </h4>

          )}

        </div>

      </div>

    </>

  );

}

export default Home;