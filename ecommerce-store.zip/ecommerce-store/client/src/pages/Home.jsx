import axios from "axios";
import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";
import ProductCard from "../components/ProductCard";

function Home() {

  const [products, setProducts] =
  useState([]);

  useEffect(() => {

    const fetchProducts =
    async () => {

      const res =
      await axios.get(
        "http://localhost:5000/api/products"
      );

      setProducts(res.data);
    };

    fetchProducts();

  }, []);

  const addToCart = async(id) => {

    const token =
    localStorage.getItem("token");

    await axios.post(

      "http://localhost:5000/api/cart",

      {
        productId:id,
        quantity:1
      },

      {
        headers:{
          Authorization:
          `Bearer ${token}`
        }
      }

    );

    alert("Added To Cart");

  };

  return (

    <>
      <Navbar />

      <div className="container mt-4">

        <h2>Products</h2>

        <div className="row">

          {products.map((product) => (

            <div
              key={product._id}
              className="col-md-4 mb-3"
            >

              <ProductCard
                product={product}
                addToCart={addToCart}
              />

            </div>

          ))}

        </div>

      </div>
    </>
  );
}

export default Home;