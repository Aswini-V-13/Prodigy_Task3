function ProductDetails() {

  return (

    <div className="container mt-5">

      <h2>
        Product Details
      </h2>

    </div>
  );
}

export default ProductDetails;