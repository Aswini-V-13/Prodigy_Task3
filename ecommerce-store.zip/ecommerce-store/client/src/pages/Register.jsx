import axios from "axios";
import { useState } from "react";
import {
  useNavigate,
  Link
} from "react-router-dom";

function Register() {

  const navigate =
  useNavigate();

  const [form,
  setForm] = useState({

    name:"",
    email:"",
    password:""

  });

  const submit =
  async (e) => {

    e.preventDefault();

    await axios.post(
      "http://localhost:5000/api/auth/register",
      form
    );

    alert(
      "Registration Successful"
    );

    navigate("/login");
  };

  return (

    <div className="container mt-5">

      <h2>Register</h2>

      <form onSubmit={submit}>

        <input
          className="form-control mb-2"
          placeholder="Name"
          onChange={(e)=>
          setForm({
            ...form,
            name:e.target.value
          })}
        />

        <input
          className="form-control mb-2"
          placeholder="Email"
          onChange={(e)=>
          setForm({
            ...form,
            email:e.target.value
          })}
        />

        <input
          type="password"
          className="form-control mb-2"
          placeholder="Password"
          onChange={(e)=>
          setForm({
            ...form,
            password:e.target.value
          })}
        />

        <button
          className="btn btn-success"
        >
          Register
        </button>

      </form>

      <p className="mt-3">

        Already have an account?

        <Link to="/login">
          Login
        </Link>

      </p>

    </div>
  );
}

export default Register;