import axios from "axios";
import { useState } from "react";
import {
  useNavigate,
  Link
} from "react-router-dom";

function Login() {

  const navigate =
  useNavigate();

  const [email,
  setEmail] = useState("");

  const [password,
  setPassword] = useState("");

  const login =
  async () => {

    const res =
    await axios.post(

      "http://localhost:5000/api/auth/login",

      {
        email,
        password
      }

    );

    localStorage.setItem(
      "token",
      res.data.token
    );

    navigate("/");
  };

  return (

    <div className="container mt-5">

      <h2>Login</h2>

      <input
        className="form-control mb-2"
        placeholder="Email"
        onChange={(e)=>
        setEmail(e.target.value)}
      />

      <input
        type="password"
        className="form-control mb-2"
        placeholder="Password"
        onChange={(e)=>
        setPassword(e.target.value)}
      />

      <button
        className="btn btn-primary"
        onClick={login}
      >
        Login
      </button>

      <p className="mt-3">

        New User?

        <Link to="/register">
          Register
        </Link>

      </p>

    </div>
  );
}

export default Login;